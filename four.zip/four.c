#include<stdio.h>
#include<string.h>

const int rows = 6;
const int columns = 7;

int timebank, time_per_move, your_botid, game_round, time_left;
char line[1000], player_names[1000], your_bot[1000], field[1000];

typedef enum {min_player = -1, blank = 0, max_player = 1} t_player;

typedef t_player t_state[6][7];

t_state state;

void print_gamefield()
{
    int i, j;
    printf("game:\n");
    
    for (i = rows-1; i >= 0; i--)
    {
        for (j = 0; j < columns; j++)
        {
            char c = (state[i][j] == 1) ? '*' : (state[i][j] == 0) ? '.' : '#';
            printf("%c ", c);
        }
        printf("\n");
    }
}

void update_gamefield(char field[])
{
    int pos = 0, inc, i, j ;

    for (i = rows-1; i >= 0; i--)
        for (j = 0; j < columns; j++)
        {
            sscanf(&field[pos], "%d%*[,;]%n", &state[i][j], &inc);
            pos += inc;
            if (state[i][j] == your_botid)
                state[i][j] = max_player;
            else if (state[i][j] != 0)
                state[i][j] = min_player;
        }
}

void print_settings()
{
    printf("settings timebank %d\n", timebank);
    printf("settings time_per_move %d\n", time_per_move);
    printf("settings player_names %s\n", player_names);
    printf("settings your_bot %s\n", your_bot);
    printf("settings your_botid %d\n", your_botid);
}

void play()
{
	printf("place_disc %d\n", rand()%7);
}

void initialize_settings()
{
    timebank = 10000;
    time_per_move = 500;
    strcpy(player_names,"player1,player2");
    strcpy(your_bot,"player1");
    your_botid = 1;
    srand(time(NULL));
}

int main()
{
	int row, column;
	t_player player;

	setbuf(stdout, NULL);

    initialize_settings();

	while (1)
	{
        if (gets(line) == NULL) break;
		if (strlen(line) == 0) continue;

        /*printf("line: %s\n", line);*/

		sscanf(line, "settings timebank %d", &timebank);
		sscanf(line, "settings time_per_move %d", &time_per_move);
		sscanf(line, "settings player_names %s", player_names);
		sscanf(line, "settings your_bot %s", your_bot);
        
		sscanf(line, "settings your_botid %d", &your_botid);
		/* sscanf(line, "settings field_columns %d", &field_columns); 	*/
		/* sscanf(line, "settings field_rows %d", &field_rows); 		*/ 
		sscanf(line, "update game round %d", &game_round);
		if (sscanf(line, "update game field %s", field)) update_gamefield(field);
		if (sscanf(line, "action move %d", &time_left)) play();
        if (strcmp(line, "field")==0) print_gamefield();
        if (strcmp(line, "dump")==0) print_settings();
	}
	return 0;
}
